export interface EntServicios {
    Id: string;
    Nombre: string;
    Descripcion: string;
    Estatus: boolean;
    Img: string | null;
    ImgPreview: string | null;
    FechaRegistro: string;
    FechaActualizacion: string;
}

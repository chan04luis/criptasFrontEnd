export interface EntServicioBySucursal {
    Id: string;
    Nombre: string;
    ImgPreview: string;
    IdAsignado: string;
    Asignado: boolean;
}

export interface SucursalUpdate {
    Id: string;
    Nombre: string;
    Telefono: string;
    Direccion: string;
    Ciudad: string;
}
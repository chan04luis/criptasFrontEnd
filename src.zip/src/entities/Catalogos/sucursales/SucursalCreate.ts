export interface SucursalCreate {
    Nombre: string;
    Telefono: string;
    Direccion: string;
    Ciudad: string;
}
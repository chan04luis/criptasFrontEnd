export interface SucursalUpdateMaps {
    Id: string;
    Latitud: string;
    Longitud: string;
}
export interface Sucursal {
    Id: string;
    Nombre: string;
    Telefono: string;
    Direccion: string;
    Ciudad: string;
    Latitud: string;
    Longitud: string;
    Estatus: boolean;
    FechaRegistro: string;
    FechaActualizacion: string;
}
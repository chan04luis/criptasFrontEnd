export interface PerfilPayload {
    ClavePerfil: string;
    NombrePerfil: string;
    Eliminable: boolean;
  }
export interface Boton {
    IdBoton: string;
    IdPagina: string;
    ClaveBoton: string;
    NombreBoton: string;
  }
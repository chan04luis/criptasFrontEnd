// config.js o constants.js
//export const apiUrl = "https://gownetwork.dyndns.org:446/api";
export const apiUrl = 'https://localhost:7045/api';
export const errorServer = 'Hubo un error desconocido.';
export const IdCliente = '2c8e4ed9-d81c-4d0c-a30f-1a8e96e73fc6'
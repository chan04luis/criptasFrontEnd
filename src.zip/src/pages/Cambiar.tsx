const Cambiar = () => {
    return (
      <div>
        <h2>Cambiar Contraseña</h2>
        <p>En esta página puedes cambiar tu contraseña.</p>
        {/* Agrega el formulario o contenido para cambiar la contraseña */}
      </div>
    );
  };
  
  export default Cambiar;
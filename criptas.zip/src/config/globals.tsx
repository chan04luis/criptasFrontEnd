// config.js o constants.js
export const apiUrl = "https://gownetwork.icu:444/api";
export const errorServer = 'Hubo un error desconocido.';

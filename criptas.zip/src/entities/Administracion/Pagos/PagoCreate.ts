export interface PagoCreate {
    IdCliente: string;
    IdCripta: string;
    IdTipoPago: string;
    MontoTotal: number;
    FechaLimite: string;
  }
export interface PagoUpdate {
    Id: string;
    IdCliente: string;
    IdCripta: string;
    IdTipoPago: string;
    MontoTotal: number;
    FechaLimite: string;
  }
export interface PagoUpdateStatus {
    Id: string;
    Estatus: boolean;
  }
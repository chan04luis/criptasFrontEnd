export interface PagoParcialidad {
    Id: string;
    IdPago: string;
    Monto: number;
    FechaPago: string;
    FechaRegistro: string;
    FechaActualizacion: string;
    Estatus: boolean;
  }
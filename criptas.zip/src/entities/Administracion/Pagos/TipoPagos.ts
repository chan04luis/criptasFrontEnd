export interface TipoPagos{
    Id:string;
    Nombre:string;
    Descripcion:string;
    Estatus:string;
}
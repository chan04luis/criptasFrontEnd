export interface PagoAplicar {
    IdPago: string;
    MontoPagado: number;
  }
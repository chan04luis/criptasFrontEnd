export interface Pagina {
    nombre: string;
    path: string;
    mostrar: boolean;
}
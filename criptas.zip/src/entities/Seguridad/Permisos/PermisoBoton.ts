export interface PermisoBoton {
    IdPermisoBoton: string;
    IdBoton: string;
    ClaveBoton: string;
    NombreBoton: string;
    TienePermiso: boolean;
  }
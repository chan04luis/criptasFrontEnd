export interface PermisosModulo {
    IdPermisoModulo: string;
    IdModulo: string;
    ClaveModulo: string;
    NombreModulo: string;
    TienePermiso: boolean;
    PermisosPagina: any;
}
export interface Zona{
    Id : string;
    IdIglesia: string | undefined;
    Nombre: string;
    FechaRegistro: string;
    FechaActualizacion: string;
    Estatus: boolean;
}
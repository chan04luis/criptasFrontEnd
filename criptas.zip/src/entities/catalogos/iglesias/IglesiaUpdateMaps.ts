export interface IglesiaUpdateMaps{
    Id: string;
    Latitud : string;
    Longitud : string;
}
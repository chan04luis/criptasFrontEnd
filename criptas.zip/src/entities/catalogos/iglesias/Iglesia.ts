export interface Iglesia{
    Id: string;
    Nombre : string;
    Direccion : string;
    Ciudad : string;
    Latitud : string;
    Longitud : string;
    Estatus: boolean;
    FechaRegistro: string;
    FechaActualizacion: string;
}
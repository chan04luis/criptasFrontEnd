export interface IglesiaByFilters{
    Id: string;
    Nombre : string;
    Ciudad : string;
    Estatus: boolean;
    NumPag: number;
    NumReg: number;
}
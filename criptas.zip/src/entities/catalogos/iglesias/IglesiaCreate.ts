export interface IglesiaCreate{
    Nombre : string;
    Direccion : string;
    Ciudad : string;
}
export interface IglesiaUpdate{
    Id: string;
    Nombre : string;
    Direccion : string;
    Ciudad : string;
}
export interface Secciones{
    Id : string;
    IdZona: string | undefined;
    Nombre: string;
    FechaRegistro: string;
    FechaActualizacion: string;
    Estatus: boolean;
}
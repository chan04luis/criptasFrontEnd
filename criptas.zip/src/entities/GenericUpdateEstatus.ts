export interface GenericUpdateEstatus{
    Id : string;
    Estatus : boolean;
}
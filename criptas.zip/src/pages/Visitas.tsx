const Visitas = () => {
    return (
      <div>
        <h2>Visitas</h2>
        <p>Esta es la página donde se gestionan las visitas.</p>
        {/* Agrega el contenido específico de las visitas aquí */}
      </div>
    );
  };
  
  export default Visitas;
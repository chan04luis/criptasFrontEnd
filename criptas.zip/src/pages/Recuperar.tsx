const Recuperar = () => {
    return (
      <div>
        <h2>Recuperar Contraseña</h2>
        <p>Si olvidaste tu contraseña, puedes recuperarla aquí.</p>
        {/* Agrega el formulario o contenido para recuperar la contraseña */}
      </div>
    );
  };
  
  export default Recuperar;
import React, { useEffect, useState } from "react";
import {
    Box,
    Typography,
    Paper,
    AppBar,
    Toolbar,
    IconButton,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    CircularProgress,
    TableFooter,
    TablePagination,
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import EditIcon from "@mui/icons-material/Edit";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import RefreshIcon from "@mui/icons-material/Refresh";
import FilterListIcon from "@mui/icons-material/FilterList";
import { toast } from "react-toastify";
import { Configuracion } from "../../../../entities/Seguridad/Configuracion";
import CustomIconButton from "../../../Utils/CustomIconButton";
import GenericFilterForm, { FilterField } from "../../../Utils/GenericFilterForm";
import { Pago } from "../../../../entities/Administracion/Pagos/Pago";
import { PagoFiltros } from "../../../../entities/Administracion/Pagos/PagoFiltros";
import ClienteSelectionModal from "./ClienteSelectionModal";
import PagosService from "../../../../services/Administracion/PagosService";
import CriptaSelectionModal from "./CriptaSelectionModal";
import { Cliente } from "../../../../entities/Cliente";

interface IndexPagosProps {
    parentConfig: Configuracion | undefined;
}

const IndexPagos: React.FC<IndexPagosProps> = ({ parentConfig }) => {
    const loadFilters = (): PagoFiltros => ({
        Id: "",
        IdCliente: "",
        IdCripta: "",
        IdTipoPago: "",
        Pagado: true,
        Estatus: true,
        NumPag: 1,
        NumReg: 10,
    });

    const [loading, setLoading] = useState<boolean>(false);
    const [totalReg, setTotalReg] = useState<number>(0);
    const [pagos, setPagos] = useState<Pago[]>([]);
    const [openModal, setOpenModal] = useState<boolean>(false);
    //const [openConfirmModal, setOpenConfirmModal] = useState<boolean>(false);
    const [filters, setFilters] = useState<PagoFiltros>(loadFilters);
    const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);
    const [openClienteModal, setOpenClienteModal] = useState<boolean>(false);
    const [openCriptaModal, setOpenCriptaModal] = useState<boolean>(false);

    const filterFields: FilterField<PagoFiltros>[] = [
        { type: "text", name: "IdCliente", label: "Cliente", value: filters.IdCliente },
        { type: "text", name: "IdCripta", label: "Cripta", value: filters.IdCripta },
        { type: "autocomplete", name: "Pagado", label: "Pagado", value: filters.Pagado, options: [{ id: true, label: "Sí" }, { id: false, label: "No" }] },
        { type: "autocomplete", name: "Estatus", label: "Estatus", value: filters.Estatus, options: [{ id: true, label: "Activo" }, { id: false, label: "Inactivo" }] },
    ];

    const fetchPagos = async () => {
        if (openModal) {

        }
        setLoading(true);
        try {
            const response = await PagosService.listPago(filters);
            if (!response.HasError) {
                setPagos(response.Result);
                setTotalReg(response.Result.length);
            } else {
                setTotalReg(0);
                setPagos([]);
                toast.warn(response.Message);
            }
        } catch (error) {
            toast.error("Error al cargar los pagos.");
        } finally {
            setLoading(false);
        }
    };

    const handlePageChange = (page: number) => {
        setFilters((prev) => ({ ...prev, NumPag: page }));
        fetchPagos();
    };

    const handlePageSizeChange = (size: number) => {
        setFilters((prev) => ({ ...prev, NumReg: size, NumPag: 1 }));
        fetchPagos();
    };

    useEffect(() => {
        fetchPagos();
    }, []);

    return (
        <Box sx={{ width: "100%", backgroundColor: "#f2f2f2", minHeight: "90vh", boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)" }}>
            <AppBar position="static" sx={{ backgroundColor: parentConfig?.ColorSecundario || "#000000" }}>
                <Toolbar>
                    <Typography variant="h6" sx={{ flexGrow: 1, color: parentConfig?.ContrasteSecundario || "#ffffff" }}>
                        Pagos
                    </Typography>
                    <Box sx={{ display: "flex", gap: 1 }}>
                        <CustomIconButton onClick={() => setOpenModal(true)} title="Agregar">
                            <AddIcon />
                        </CustomIconButton>
                        <CustomIconButton onClick={fetchPagos} title="Refrescar">
                            <RefreshIcon />
                        </CustomIconButton>
                        <CustomIconButton onClick={() => setIsDrawerOpen(true)} title="Filtros">
                            <FilterListIcon />
                        </CustomIconButton>
                    </Box>
                </Toolbar>
            </AppBar>

            <Paper elevation={3} sx={{ margin: 2, padding: 2 }}>
                {loading ? (
                    <Box sx={{ display: "flex", justifyContent: "center", marginTop: 4 }}>
                        <CircularProgress />
                    </Box>
                ) : (
                    <TableContainer>
                        <Table>
                            <TableHead>
                                <TableRow>
                                    <TableCell>Cliente</TableCell>
                                    <TableCell>Cripta</TableCell>
                                    <TableCell>Monto Total</TableCell>
                                    <TableCell>Fecha Límite</TableCell>
                                    <TableCell>Pagado</TableCell>
                                    <TableCell>Estatus</TableCell>
                                    <TableCell>Acciones</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {pagos.map((pago) => (
                                    <TableRow key={pago.Id}>
                                        <TableCell>{pago.IdCliente}</TableCell>
                                        <TableCell>{pago.IdCripta}</TableCell>
                                        <TableCell>${pago.MontoTotal.toFixed(2)}</TableCell>
                                        <TableCell>{new Date(pago.FechaLimite).toLocaleDateString()}</TableCell>
                                        <TableCell>{pago.Pagado ? "Sí" : "No"}</TableCell>
                                        <TableCell>{pago.Estatus ? "Activo" : "Inactivo"}</TableCell>
                                        <TableCell>
                                            <IconButton title="Editar">
                                                <EditIcon />
                                            </IconButton>
                                            <IconButton title="Eliminar" sx={{ color: "red" }}>
                                                <DeleteForeverIcon />
                                            </IconButton>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                            <TableFooter>
                                <TableRow>
                                    <TableCell colSpan={7}>
                                        <Box display="flex" justifyContent="center">
                                            <TablePagination
                                                component="div"
                                                count={totalReg}
                                                page={filters.NumPag - 1}
                                                onPageChange={(_, newPage) => handlePageChange(newPage + 1)}
                                                rowsPerPage={filters.NumReg}
                                                onRowsPerPageChange={(e) => handlePageSizeChange(parseInt(e.target.value, 10))}
                                                rowsPerPageOptions={[10, 20, 50, 100]}
                                                labelRowsPerPage="Registros por página:"
                                                labelDisplayedRows={({ from, to, count }) => `${from}–${to} de ${count !== -1 ? count : `más de ${to}`}`}
                                            />
                                        </Box>
                                    </TableCell>
                                </TableRow>
                            </TableFooter>
                        </Table>
                    </TableContainer>
                )}
            </Paper>

            <GenericFilterForm filters={filters} setFilters={setFilters} onSearch={fetchPagos} isDrawerOpen={isDrawerOpen} toggleDrawer={() => setIsDrawerOpen(!isDrawerOpen)} fields={filterFields} />

            <ClienteSelectionModal
                open={openClienteModal}
                onClose={() => setOpenClienteModal(false)}
                onSelect={(cliente: Cliente) => setFilters((prev) => ({ ...prev, IdCliente: cliente.Id }))}
            />


            <CriptaSelectionModal open={openCriptaModal} onClose={() => setOpenCriptaModal(false)} onSelect={(cripta) => setFilters((prev) => ({ ...prev, IdCripta: cripta.Id }))} />
        </Box>
    );
};

export default IndexPagos;

import React, { useEffect, useState } from "react";
import {
    Box,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    TableFooter,
    TablePagination,
    CircularProgress,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Button,
} from "@mui/material";
import ClienteService from "../../../../services/Catalogos/ClienteService";
import { Cliente, ClienteFilters } from "../../../../entities/Cliente";
import GenericFilterForm, { FilterField } from "../../../Utils/GenericFilterForm";

interface ClienteSelectionModalProps {
    open: boolean;
    onClose: () => void;
    onSelect: (cliente: Cliente) => void;
}

const ClienteSelectionModal: React.FC<ClienteSelectionModalProps> = ({
    open,
    onClose,
    onSelect,
}) => {
    const [loading, setLoading] = useState<boolean>(false);
    const [clientes, setClientes] = useState<Cliente[]>([]);
    const [totalReg, setTotalReg] = useState<number>(0);
    const [filters, setFilters] = useState<ClienteFilters>({
        Id: "",
        Nombre: "",
        Apellido: "",
        Estatus: true,
        NumPag: 1,
        NumReg: 10,
    });

    const fetchClientes = async () => {
        setLoading(true);
        try {
            const response = await ClienteService.getClientesByFilters(filters);
            if (!response.HasError) {
                setClientes(response.Result.Items || []);
                setTotalReg(response.Result.TotalRecords);
            } else {
                setClientes([]);
            }
        } catch (error) {
            console.error("Error al obtener clientes", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (open) fetchClientes();
    }, [open, filters]);

    const filterFields: FilterField<ClienteFilters>[] = [
        { type: "text", name: "Nombre", label: "Nombre", value: filters.Nombre },
        { type: "text", name: "Apellido", label: "Apellido", value: filters.Apellido },
        { type: "autocomplete", name: "Estatus", label: "Estatus", value: filters.Estatus, options: [{ id: true, label: "Activo" }, { id: false, label: "Inactivo" }] },
    ];

    return (
        <Dialog open={open} onClose={onClose} fullWidth maxWidth="md">
            <DialogTitle>Seleccionar Cliente</DialogTitle>
            <DialogContent>
                <GenericFilterForm
                    filters={filters}
                    setFilters={setFilters}
                    onSearch={fetchClientes}
                    isDrawerOpen={true}
                    toggleDrawer={() => { }}
                    fields={filterFields}
                />
                <Paper elevation={3} sx={{ marginTop: 2 }}>
                    {loading ? (
                        <Box sx={{ display: "flex", justifyContent: "center", marginTop: 4 }}>
                            <CircularProgress />
                        </Box>
                    ) : (
                        <TableContainer>
                            <Table>
                                <TableHead>
                                    <TableRow>
                                        <TableCell>Nombre</TableCell>
                                        <TableCell>Correo</TableCell>
                                        <TableCell>Teléfono</TableCell>
                                        <TableCell>Seleccionar</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {clientes.map((cliente) => (
                                        <TableRow key={cliente.Id}>
                                            <TableCell>{`${cliente.Nombres} ${cliente.Apellidos}`}</TableCell>
                                            <TableCell>{cliente.Email}</TableCell>
                                            <TableCell>{cliente.Telefono}</TableCell>
                                            <TableCell>
                                                <Button variant="contained" color="primary" onClick={() => onSelect(cliente)}>
                                                    Seleccionar
                                                </Button>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                                <TableFooter>
                                    <TableRow>
                                        <TablePagination
                                            count={totalReg}
                                            page={filters.NumPag - 1}
                                            onPageChange={(_, newPage) => setFilters({ ...filters, NumPag: newPage + 1 })}
                                            rowsPerPage={filters.NumReg}
                                            onRowsPerPageChange={(e) => setFilters({ ...filters, NumReg: parseInt(e.target.value, 10), NumPag: 1 })}
                                            rowsPerPageOptions={[10, 20, 50, 100]}
                                            labelRowsPerPage="Registros por página:"
                                        />
                                    </TableRow>
                                </TableFooter>
                            </Table>
                        </TableContainer>
                    )}
                </Paper>
            </DialogContent>
            <DialogActions>
                <Button onClick={onClose} color="secondary">Cancelar</Button>
            </DialogActions>
        </Dialog>
    );
};

export default ClienteSelectionModal;
